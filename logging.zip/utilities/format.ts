export function lines(...lines: string[]): string {
    return lines.join('\n');
}